# 📲 Como Instalar o App do Miguel no Celular Android

## O que você vai precisar
- Um celular Android com Google Chrome
- Um servidor web para hospedar os arquivos (veja opções abaixo)

---

## 📁 Estrutura dos Arquivos

Após extrair o ZIP, você terá:
```
miguel-pwa/
├── index.html        ← Arquivo principal do app
├── manifest.json     ← Configurações do PWA
├── sw.js             ← Service Worker (funciona offline)
└── icons/
    ├── icon-72x72.png
    ├── icon-96x96.png
    ├── icon-128x128.png
    ├── icon-144x144.png
    ├── icon-152x152.png
    ├── icon-192x192.png
    ├── icon-384x384.png
    └── icon-512x512.png
```

---

## 🌐 OPÇÃO 1 — Hospedar no GitHub Pages (gratuito e fácil)

1. Acesse https://github.com e crie uma conta gratuita
2. Clique em **"New repository"**
3. Nome: `miguel-aprende` — marque como **Public**
4. Clique em **"uploading an existing file"**
5. Arraste **todos os arquivos e a pasta `icons`** para lá
6. Clique em **"Commit changes"**
7. Vá em **Settings → Pages → Branch: main → Save**
8. Seu app ficará em: `https://SEU-USUARIO.github.io/miguel-aprende/`

---

## 🌐 OPÇÃO 2 — Hospedar no Netlify (arrasta e solta, gratuito)

1. Acesse https://netlify.com e crie uma conta gratuita
2. Na dashboard, arraste a **pasta `miguel-pwa` inteira** para a área indicada
3. Pronto! O Netlify gera um link como `https://nome-aleatorio.netlify.app`

---

## 📲 Como Instalar no Android (após hospedar)

1. Abra o **Google Chrome** no celular Android
2. Acesse a URL do seu app hospedado
3. Aguarde ~2 segundos — aparecerá um banner na parte de baixo:
   **"Instalar no celular do Miguel!"**
4. Toque em **"Instalar"**
5. O app aparecerá na tela inicial do celular como qualquer outro app! 🎉

### Instalação Manual (se o banner não aparecer):
1. No Chrome, toque nos **3 pontinhos** (⋮) no canto superior direito
2. Toque em **"Adicionar à tela inicial"** ou **"Instalar app"**
3. Confirme tocando em **"Instalar"**

---

## ✅ Funcionalidades após instalação

| Recurso | Funciona |
|---------|---------|
| Ícone na tela inicial | ✅ |
| Funciona offline (sem internet) | ✅ |
| Tela cheia (sem barra do navegador) | ✅ |
| Som e voz em português | ✅ |
| Atualizações automáticas | ✅ |

---

## ❓ Dúvidas?

- O app funciona **100% offline** após a primeira visita
- A **voz em português** depende do celular ter o pacote de voz pt-BR instalado
  - Para instalar: Configurações → Acessibilidade → Texto para fala → Baixar idioma Português
- Funciona também em **iPhone** pelo Safari (Compartilhar → Adicionar à Tela de Início)

---

💛 Feito com amor por Papai Paulo e Mamãe Dani para o Miguel 💙
