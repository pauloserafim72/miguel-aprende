// ===================================================
// Service Worker — Toque e Aprenda (Miguel PWA)
// Versão do cache — atualize para forçar novo cache
// ===================================================
const CACHE_NAME = 'miguel-aprende-v1';

// Todos os arquivos que precisam funcionar offline
const FILES_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-72x72.png',
  './icons/icon-96x96.png',
  './icons/icon-128x128.png',
  './icons/icon-144x144.png',
  './icons/icon-152x152.png',
  './icons/icon-192x192.png',
  './icons/icon-384x384.png',
  './icons/icon-512x512.png',
];

// ---- INSTALL: salva tudo no cache ----
self.addEventListener('install', event => {
  console.log('[SW] Instalando e salvando cache...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(FILES_TO_CACHE);
    }).then(() => self.skipWaiting())
  );
});

// ---- ACTIVATE: limpa caches antigos ----
self.addEventListener('activate', event => {
  console.log('[SW] Ativando novo Service Worker...');
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ---- FETCH: serve do cache, busca na rede se necessário ----
self.addEventListener('fetch', event => {
  // Fontes do Google — tenta rede primeiro, cache como fallback
  if (event.request.url.includes('fonts.googleapis.com') ||
      event.request.url.includes('fonts.gstatic.com')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(cache =>
        fetch(event.request)
          .then(response => {
            cache.put(event.request, response.clone());
            return response;
          })
          .catch(() => caches.match(event.request))
      )
    );
    return;
  }

  // Demais recursos — cache first
  event.respondWith(
    caches.match(event.request).then(cached => {
      return cached || fetch(event.request).catch(() => {
        // Fallback para o index.html se offline e recurso não cacheado
        if (event.request.destination === 'document') {
          return caches.match('./index.html');
        }
      });
    })
  );
});
